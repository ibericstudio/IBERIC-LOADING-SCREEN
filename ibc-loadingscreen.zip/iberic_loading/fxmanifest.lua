fx_version 'cerulean'
game 'gta5'

author 'IBERIC PROJECT'
description 'IBERIC PROJECT Loading Screen - ESX / QBCore'
version '2.1.0'

loadscreen 'html/index.html'
loadscreen_manual_shutdown 'yes'
loadscreen_cursor 'yes'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/config.js',
    'html/assets/**'
}

shared_script 'config.lua'
client_script 'client.lua'
