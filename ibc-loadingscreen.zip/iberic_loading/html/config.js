/*
  IBERIC PROJECT - CONFIGURACION
  Puedes cambiar logo, colores, musica y textos desde este archivo.
*/
window.IBERIC_LOADING_CONFIG = {
    serverName: "IBERIC PROJECT",
    subtitle: "IBERIC PROJECT",

    accent: "#a855f7",
    accentSecondary: "#6d28d9",
    textColor: "#f5f0ff",

    backgroundStyle: "topography",
    logo: "assets/iberic-project-logo.png",

    // Usa music.mp3 (recomendado para CEF). El MP4 original tambien se conserva.
    enableMusic: true,
    musicUrl: "assets/music.mp3",
    musicVolume: 0.35,
    autoplayMusic: true,

    showTips: true,
    tips: [
        "Respeta a los demas jugadores y disfruta del rol.",
        "Lee las normativas antes de comenzar tu aventura.",
        "Usa los canales correspondientes para solicitar ayuda.",
        "El rol de calidad lo construimos entre todos."
    ]
};
