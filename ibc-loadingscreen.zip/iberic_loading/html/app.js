(() => {
    'use strict';

    const cfg = window.IBERIC_LOADING_CONFIG || {};
    const byId = (id) => document.getElementById(id);
    const setText = (id, value) => { const el = byId(id); if (el) el.textContent = value; };
    const safeString = (value, fallback) =>
        (typeof value === 'string' && value.trim()) ? value.trim() : fallback;

    const root = document.documentElement;
    root.style.setProperty('--accent', safeString(cfg.accent, '#a855f7'));
    root.style.setProperty('--accent-2', safeString(cfg.accentSecondary, '#6d28d9'));
    root.style.setProperty('--text', safeString(cfg.textColor, '#f5f0ff'));

    setText('serverName', safeString(cfg.serverName, 'IBERIC PROJECT'));
    setText('subtitle', safeString(cfg.subtitle, 'IBERIC PROJECT'));

    // Logo: PNG real incluido en el recurso, con fallback visible si se cambia mal la ruta.
    const logo = byId('serverLogo');
    if (logo) {
        logo.src = safeString(cfg.logo, 'assets/iberic-project-logo.png');
        logo.addEventListener('error', () => {
            logo.style.display = 'none';
            const logoColumn = document.querySelector('.logo-column');
            if (logoColumn && !byId('logoFallback')) {
                const fallback = document.createElement('div');
                fallback.id = 'logoFallback';
                fallback.className = 'logo-fallback';
                fallback.textContent = 'IBERIC PROJECT';
                logoColumn.insertBefore(fallback, logoColumn.firstChild);
            }
        });
    }

    if (cfg.backgroundStyle !== 'topography') {
        const background = document.querySelector('.background');
        if (background) background.style.backgroundImage =
            'radial-gradient(ellipse at 50% 45%, rgba(81,28,130,.2), transparent 55%)';
    }

    const tips = Array.isArray(cfg.tips) ? cfg.tips.filter(t => typeof t === 'string' && t.trim()) : [];
    if (cfg.showTips === false) {
        byId('tipArea').hidden = true;
    } else if (tips.length) {
        let tipIndex = 0;
        setText('tipText', tips[0]);
        window.setInterval(() => {
            tipIndex = (tipIndex + 1) % tips.length;
            const tip = byId('tipText');
            if (!tip) return;
            tip.classList.add('tip-changing');
            window.setTimeout(() => {
                setText('tipText', tips[tipIndex]);
                tip.classList.remove('tip-changing');
            }, 180);
        }, 6500);
    }

    // Audio: se utiliza MP3 convertido desde el MP4 original para compatibilidad CEF.
    const audio = byId('audio');
    const musicButton = byId('musicToggle');
    const musicIcon = byId('musicIcon');
    const volumeSlider = byId('volumeSlider');
    const volumeValue = byId('volumeValue');
    const musicState = byId('musicState');
    let audioReady = false;

    const setMusicState = (playing, message) => {
        if (musicIcon) musicIcon.textContent = playing ? 'Ⅱ' : '▶';
        if (musicButton) {
            musicButton.setAttribute('aria-label', playing ? 'Pausar musica' : 'Reproducir musica');
            musicButton.classList.toggle('is-playing', playing);
        }
        if (musicState) musicState.textContent = message || (playing ? 'REPRODUCIENDO' : 'EN PAUSA');
    };

    if (cfg.enableMusic !== false && audio && musicButton) {
        audio.src = safeString(cfg.musicUrl, 'assets/music.mp3');
        audio.loop = true;
        audio.volume = Math.max(0, Math.min(1, Number(cfg.musicVolume ?? 0.35)));

        const initialVolume = Math.round(audio.volume * 100);
        volumeSlider.value = String(initialVolume);
        volumeValue.textContent = initialVolume + '%';

        audio.addEventListener('canplay', () => {
            audioReady = true;
            if (musicState && audio.paused) musicState.textContent = 'LISTA PARA REPRODUCIR';
        });
        audio.addEventListener('playing', () => setMusicState(true, 'REPRODUCIENDO'));
        audio.addEventListener('pause', () => setMusicState(false, 'EN PAUSA'));
        audio.addEventListener('ended', () => {
            if (cfg.musicLoop !== false) {
                audio.currentTime = 0;
                audio.play().catch(() => setMusicState(false, 'PULSA PLAY PARA ESCUCHAR'));
            }
        });
        audio.addEventListener('error', () => {
            setMusicState(false, 'ERROR DE AUDIO - REVISA music.mp3');
        });

        const playAudio = () => {
            const promise = audio.play();
            if (promise && typeof promise.then === 'function') {
                promise.then(() => setMusicState(true, 'REPRODUCIENDO'))
                    .catch(() => setMusicState(false, 'PULSA PLAY PARA ESCUCHAR'));
            }
        };

        musicButton.addEventListener('click', () => {
            if (audio.paused) playAudio();
            else audio.pause();
        });

        volumeSlider.addEventListener('input', () => {
            const value = Math.max(0, Math.min(100, Number(volumeSlider.value)));
            audio.volume = value / 100;
            audio.muted = value === 0;
            volumeValue.textContent = value + '%';
        });

        // Algunos CEF bloquean autoplay hasta la primera interaccion del usuario.
        // Reintenta una vez al primer click/tecla sin impedir controles.
        if (cfg.autoplayMusic !== false) {
            playAudio();
            const unlock = () => {
                if (audio.paused) playAudio();
                document.removeEventListener('pointerdown', unlock);
                document.removeEventListener('keydown', unlock);
            };
            document.addEventListener('pointerdown', unlock, { once: true });
            document.addEventListener('keydown', unlock, { once: true });
        }
    } else {
        const box = byId('musicBox');
        if (box) box.hidden = true;
    }

    // FiveM loadscreen event progress, with a restrained visual fallback.
    let receivedNativeProgress = false;
    let currentProgress = 0;

    const setProgress = (value) => {
        let n = Number(value);
        if (!Number.isFinite(n)) return;
        if (n >= 0 && n <= 1) n *= 100;
        n = Math.max(0, Math.min(100, n));
        currentProgress = n;

        const fill = byId('progressFill');
        const track = byId('progressTrack');
        if (fill) fill.style.width = n + '%';
        if (track) track.setAttribute('aria-valuenow', String(Math.round(n)));
        setText('progressPercent', Math.round(n) + '%');
        setText('progressLabel', n >= 100 ? 'SERVIDOR CARGADO' : 'ACCEDIENDO AL SERVIDOR...');
        setText('progressDetail', n >= 100 ? 'LISTO PARA ENTRAR' : 'CARGANDO RECURSOS');
        if (n >= 100) setText('connectionText', 'CARGA COMPLETADA');
    };

    window.addEventListener('message', (event) => {
        const data = event.data || {};
        if (data.eventName === 'loadProgress' && data.loadFraction !== undefined) {
            receivedNativeProgress = true;
            setProgress(data.loadFraction);
        } else if (data.type === 'loadProgress' && data.progress !== undefined) {
            receivedNativeProgress = true;
            setProgress(data.progress);
        }
    });

    const startedAt = Date.now();
    const fallbackTimer = window.setInterval(() => {
        if (receivedNativeProgress) {
            window.clearInterval(fallbackTimer);
            return;
        }
        const elapsed = (Date.now() - startedAt) / 1000;
        const target = Math.min(92, 4 + elapsed * 1.35);
        if (target > currentProgress) setProgress(target);
    }, 650);
})();
