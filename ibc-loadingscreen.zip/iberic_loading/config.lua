Config = {}

-- Framework: 'auto', 'esx', 'qbcore' or 'standalone'
Config.Framework = 'auto'

-- Close the loading screen when the selected framework reports player loaded.
Config.CloseOnPlayerLoaded = true

-- Safety fallback in seconds. Set to 0 to disable.
-- This prevents the loading screen remaining forever if a framework event is missed.
Config.FallbackCloseSeconds = 180

-- Optional extra events from your own character/spawn resource.
-- Example: { 'my_multicharacter:client:spawned' }
Config.ExtraLoadedEvents = {}

-- Debug prints
Config.Debug = false
