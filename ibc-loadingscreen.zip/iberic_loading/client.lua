local closed = false

local function debugPrint(message)
    if Config.Debug then
        print(('[iberic_loading] %s'):format(message))
    end
end

local function closeLoadingScreen(reason)
    if closed then return end
    closed = true

    debugPrint(('Closing loading screen (%s)'):format(reason or 'unknown'))
    ShutdownLoadingScreenNui()
    ShutdownLoadingScreen()
end

local function detectFramework()
    if Config.Framework and Config.Framework ~= 'auto' then
        return Config.Framework
    end

    if GetResourceState('es_extended') == 'started' then
        return 'esx'
    end

    if GetResourceState('qb-core') == 'started' then
        return 'qbcore'
    end

    return 'standalone'
end

CreateThread(function()
    Wait(1000)

    if not Config.CloseOnPlayerLoaded then
        debugPrint('Automatic close disabled in config.')
        return
    end

    local framework = detectFramework()
    debugPrint(('Detected framework: %s'):format(framework))

    if framework == 'esx' then
        RegisterNetEvent('esx:playerLoaded')
        AddEventHandler('esx:playerLoaded', function()
            Wait(1500)
            closeLoadingScreen('esx:playerLoaded')
        end)
    elseif framework == 'qbcore' then
        RegisterNetEvent('QBCore:Client:OnPlayerLoaded')
        AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
            Wait(1500)
            closeLoadingScreen('QBCore:Client:OnPlayerLoaded')
        end)
    end

    for _, eventName in ipairs(Config.ExtraLoadedEvents or {}) do
        if type(eventName) == 'string' and eventName ~= '' then
            RegisterNetEvent(eventName)
            AddEventHandler(eventName, function()
                Wait(1000)
                closeLoadingScreen(eventName)
            end)
        end
    end

    if framework == 'standalone' then
        debugPrint('Standalone mode: use ExtraLoadedEvents or the fallback timer.')
    end
end)

if Config.FallbackCloseSeconds and Config.FallbackCloseSeconds > 0 then
    CreateThread(function()
        Wait(Config.FallbackCloseSeconds * 1000)
        closeLoadingScreen('fallback timer')
    end)
end

-- Optional manual close event for custom spawn systems.
RegisterNetEvent('iberic_loading:client:close', function()
    closeLoadingScreen('manual event')
end)
